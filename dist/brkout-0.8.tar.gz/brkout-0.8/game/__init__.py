import main

def main():
    main.main()